describe('Sinister API Tests', () => {
    const baseUrl = 'http://localhost:8080/api/sinister'; 
  
    it('GET /api/sinister - Deve retornar todos os sinistros', () => {
      cy.request({
        method: 'GET',
        url: baseUrl
      }).then((response) => {
        expect(response.status).to.equal(200);
        expect(response.body).to.be.an('array'); // Verifica que o retorno é uma lista
        if (response.body.length > 0) {
          expect(response.body[0]).to.have.property('id');
          expect(response.body[0]).to.have.property('identification');
          expect(response.body[0]).to.have.property('gravity');
        }
      });
    });
  
    it('GET /api/sinister/{id} - Deve retornar sinistro por ID', () => {
      const sinisterId = 1; // Ajuste para um ID válido no banco de dados
  
      cy.request({
        method: 'GET',
        url: `${baseUrl}/${sinisterId}`
      }).then((response) => {
        expect(response.status).to.equal(200);
        expect(response.body).to.have.property('identification');
        expect(response.body).to.have.property('gravity');
      });
    });
  
    it('GET /api/sinister/{id} - Deve retornar erro 404 para sinistro inexistente', () => {
      const nonexistentId = 9999; // ID de sinistro que não existe
  
      cy.request({
        method: 'GET',
        url: `${baseUrl}/${nonexistentId}`,
        failOnStatusCode: false
      }).then((response) => {
        expect(response.status).to.equal(404); // Confirma que o status de erro é 404
        expect(response.body.message).to.equal(`Sinister with ID ${nonexistentId} not found`);
      });
    });
  });
  