describe('Optional API Tests', () => {
    const baseUrl = 'http://localhost:8080/api/optional'; 

    it('Deve listar todos os opcionais', () => {
      cy.request({
        method: 'GET',
        url: baseUrl,
      }).then((response) => {
        expect(response.status).to.equal(200);
        expect(response.body).to.be.an('array'); // Verifica que a resposta é uma lista
        response.body.forEach((optional) => {
          expect(optional).to.have.all.keys('id', 'name', 'valueLocation', 'valueDeclared', 'qtdAvailable');
        });
      });
    });
  
    it('Deve retornar um opcional por ID', () => {
    
      const id = 1; 
  
      cy.request({
        method: 'GET',
        url: `${baseUrl}/${id}`,
        failOnStatusCode: false 
      }).then((response) => {
        if (response.status === 200) {
          expect(response.body).to.be.an('object');
          expect(response.body).to.have.property('name');
          expect(response.body).to.have.property('valueLocation');
          expect(response.body).to.have.property('valueDeclared');
          expect(response.body).to.have.property('qtdAvailable');
        } else {
          // 
          expect(response.status).to.equal(404);
          expect(response.body.message).to.include('not found');
        }
      });
    });
  
    it('Deve retornar erro para ID inexistente', () => {
      const invalidId = 9999;
  
      cy.request({
        method: 'GET',
        url: `${baseUrl}/${invalidId}`,
        failOnStatusCode: false
      }).then((response) => {
        expect(response.status).to.equal(404);
        expect(response.body.message).to.include('not found');
      });
    });
  });
  