describe('Vehicle API Tests', () => {
    const baseUrl = 'http://localhost:8080/api/vehicles'; // Ajuste conforme necessário

    const vehicleSample = {
        name: "Civic",
        manufacturer: "Honda",
        version: "2020",
        urlFipe: "------",
        plate: "ABC1D23",
        color: "Black",
        exchange: "Automatic",
        km: 15000,
        capacityPassengers: 5,
        volumeLoad: 400,
        accessories: ["Air Conditioning", "GPS"],
        valuedaily: 100.0,
        categoryId: 5 
    };

    let vehicleId;

    it('Criar Novo Veiculo', () => {
        cy.request({
            method: 'POST',
            url: baseUrl,
            body: vehicleSample,
            failOnStatusCode: false
        }).then((response) => {
            expect(response.status).to.eq(200);
            expect(response.body).to.have.property('id');
            vehicleId = response.body.id; // Armazena o ID do veículo criado para testes futuros
        });
    });

    it('Listar Todos Veiculos', () => {
        cy.request(baseUrl).then((response) => {
            expect(response.status).to.eq(200);
            expect(response.body).to.be.an('array');
            expect(response.body).to.have.length.greaterThan(0);
        });
    });

    it('Editar Veiculo Existente', () => {
        const updatedVehicle = {
            ...vehicleSample,
            name: "Civic Updated" // Mudança no nome para editar
        };

        cy.request({
            method: 'PUT',
            url: `${baseUrl}/${vehicleId}`,
            body: updatedVehicle,
            failOnStatusCode: false
        }).then((response) => {
            expect(response.status).to.eq(200);
            expect(response.body.name).to.eq("Civic Updated");
        });
    });

    it('Deletar Veiculo Existente', () => {
        cy.request({
            method: 'DELETE',
            url: `${baseUrl}/${vehicleId}`,
            failOnStatusCode: false
        }).then((response) => {
            expect(response.status).to.eq(204); // Código 204 No Content
        });
    });

    it('Veiculo Não Encontrado', () => {
        cy.request({
            method: 'GET',
            url: `${baseUrl}/${vehicleId}`,
            failOnStatusCode: false // Não falhar se o status for 404
        }).then((response) => {
            expect(response.status).to.eq(404); // Verifica que o veículo foi realmente excluído
        });
    });

    it('Erro ao Criar Veículo com Placa Duplicada', () => {
        cy.request({
            method: 'POST',
            url: baseUrl,
            body: vehicleSample,
            failOnStatusCode: false
        }).then((response) => {
            expect(response.status).to.eq(400); // Código 400 Bad Request para duplicidade
            expect(response.body.message).to.contain("Veículo com está placa já cadastrado");
        });
    });
});
