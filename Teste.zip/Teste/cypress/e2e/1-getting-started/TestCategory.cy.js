describe('Category API Tests', () => {
    const baseUrl = 'http://localhost:8080/api/categories'; 
    let categoryId; 
  
    before(() => {
      cy.request('DELETE', `${baseUrl}`); 
    });
  
    it('Deve criar uma nova categoria', () => {
      const category = {
        name: 'Categoria A',
        fine1To4Days: 10.0,
        fine5To9Days: 20.0,
        fine10DaysOrMore: 30.0,
      };
  
      cy.request('POST', baseUrl, category).then((response) => {
        expect(response.status).to.eq(200);
        expect(response.body).to.have.property('name', category.name);
        categoryId = response.body.id;
      });
    });
  
    it('Deve listar todas as categorias', () => {
      cy.request('GET', baseUrl).then((response) => {
        expect(response.status).to.eq(200);
        expect(response.body).to.be.an('array');
        expect(response.body.length).to.be.greaterThan(0);
      });
    });
  
    it('Deve obter uma categoria por ID', () => {
      cy.request('GET', `${baseUrl}/${categoryId}`).then((response) => {
        expect(response.status).to.eq(200);
        expect(response.body).to.have.property('id', categoryId);
      });
    });
  
    it('Deve atualizar uma categoria existente', () => {
      const updatedCategory = {
        name: 'Categoria Atualizada',
        fine1To4Days: 15.0,
        fine5To9Days: 25.0,
        fine10DaysOrMore: 35.0,
      };
  
      cy.request('PUT', `${baseUrl}/${categoryId}`, updatedCategory).then((response) => {
        expect(response.status).to.eq(200);
        expect(response.body).to.have.property('name', updatedCategory.name);
      });
    });
  
    it('Deve deletar uma categoria por ID', () => {
      cy.request('DELETE', `${baseUrl}/${categoryId}`).then((response) => {
        expect(response.status).to.eq(204);
      });
    });
  
    it('Deve retornar 404 para uma categoria não encontrada', () => {
      cy.request({
        method: 'GET',
        url: `${baseUrl}/99999`,
        failOnStatusCode: false,
      }).then((response) => {
        expect(response.status).to.eq(404);
      });
    });
  });
  