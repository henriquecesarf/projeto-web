describe('Client API Tests', () => {
    
    const baseUrl = 'http://localhost:8080/api/client';

    
    const clientData = {
        name: 'João',
        surname: 'Farid',
        cpf: '12345678909',
        email: 'joao.farid@gmail.com',
        sexo: 'M',
        dtNascimento: '1990-01-01',
        cnh: '12345678900',
        cnhCategory: 'B',
        cnhDtMaturity: '2025-01-01',
        cep: '12345678',
        address: 'Rua Logo Ali, 123',
        country: 'Brasil',
        city: 'São Paulo',
        state: 'SP',
        complement: 'Apto 101'
    };

    it('Teste para criação de cliente', () => {
        cy.request('POST', baseUrl, clientData)
          .then((response) => {
              expect(response.status).to.eq(200);
              expect(response.body).to.have.property('id');
              expect(response.body.name).to.eq(clientData.name);
          });
    });

    it('Teste para obter todos os clientes', () => {
        cy.request('GET', baseUrl)
          .then((response) => {
              expect(response.status).to.eq(200);
              expect(response.body).to.be.an('array');
          });
    });

    it('Teste para obter um cliente por ID', () => {
        cy.request('POST', baseUrl, clientData).then((postResponse) => {
            const clientId = postResponse.body.id;
            cy.request('GET', `${baseUrl}/${clientId}`)
              .then((getResponse) => {
                  expect(getResponse.status).to.eq(200);
                  expect(getResponse.body.id).to.eq(clientId);
                  expect(getResponse.body.name).to.eq(clientData.name);
              });
        });
    });

    it('Teste para atualizar cliente', () => {
        cy.request('POST', baseUrl, clientData).then((postResponse) => {
            const clientId = postResponse.body.id;
            const updatedData = { ...clientData, name: 'Carim' };

            cy.request('PUT', `${baseUrl}/${clientId}`, updatedData)
              .then((putResponse) => {
                  expect(putResponse.status).to.eq(200);
                  expect(putResponse.body.name).to.eq('Carim');
              });
        });
    });

    it('Teste para atualização parcial (PATCH) de cliente', () => {
        cy.request('POST', baseUrl, clientData).then((postResponse) => {
            const clientId = postResponse.body.id;
            const partialData = { name: 'Johnny' };

            cy.request('PATCH', `${baseUrl}/${clientId}`, partialData)
              .then((patchResponse) => {
                  expect(patchResponse.status).to.eq(200);
                  expect(patchResponse.body.name).to.eq('João');
              });
        });
    });

    it('Teste para deletar cliente', () => {
        cy.request('POST', baseUrl, clientData).then((postResponse) => {
            const clientId = postResponse.body.id;
            cy.request('DELETE', `${baseUrl}/${clientId}`)
              .then((deleteResponse) => {
                  expect(deleteResponse.status).to.eq(204);
              });
            
            cy.request({
                method: 'GET',
                url: `${baseUrl}/${clientId}`,
                failOnStatusCode: false
            }).then((getResponse) => {
                expect(getResponse.status).to.eq(404);
            });
        });
    });
});
